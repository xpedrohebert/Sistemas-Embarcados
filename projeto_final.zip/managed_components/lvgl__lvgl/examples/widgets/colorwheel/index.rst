
Simple Colorwheel
"""""""""""""""""

.. lv_example:: widgets/colorwheel/lv_example_colorwheel_1
  :language: c

